import React from 'react';
import SearchBaseScreen from './SearchBaseScreen'; // 경로 확인

function UnifiedSearchScreen() {
  return (
    <SearchBaseScreen title="피해 사례 검색" />
  );
}
export default UnifiedSearchScreen;
